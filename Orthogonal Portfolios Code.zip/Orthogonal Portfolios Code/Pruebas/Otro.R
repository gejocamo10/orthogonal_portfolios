library("UnivRNG")
table1_portfolio_result <- function(sigma, mu, gamma, type){
  unit_vector <- rep(1,length(sigma))
  if (type == "S") {
    weight <- (1/gamma) * solve(sigma) %*% mu
    sqr_shrp <- t(mu) * solve(sigma) %*% mu
    utility <-  (sqr_shrp^2)/(2*gamma)
  }
  if (type == "G") {
    weight <- solve(sigma) %*% unit_vector / (t(unit_vector)%*%solve(sigma)%*%unit_vector)
    sqr_shrp <- ((t(mu)%*%solve(sigma)%*%unit_vector)^2)/((t(unit_vector)%*%solve(sigma)%*%unit_vector))
    mu_G <- weight %*% mu
    sqr_sigma_G <- t(weight)%*%sigma%*%weight
    utility <-  mu_G - (gamma/2)*sqr_sigma_G
  }
  if (type == "G~") {
    weight_G <- solve(sigma) %*% unit_vector / (t(unit_vector)%*%solve(sigma)%*%unit_vector)
    sqr_shrp_G <- ((t(mu)%*%solve(sigma)%*%unit_vector)^2)/((t(unit_vector)%*%solve(sigma)%*%unit_vector))
    mu_G <- weight_G %*% mu
    sqr_sigma_G <- t(weight_G)%*%sigma%*%weight_G
    weight <- solve(sigma) %*% unit_vector
    sqr_shrp <- sqr_shrp_G
    utility <-  mu_G/sqr_sigma_G - (gamma/2)*(1/sqr_sigma_G)
  }
  if (type == "H") {
    R <- solve(sigma) - (solve(sigma)%*%unit_vector%*%t(unit_vector)%*%solve(sigma))/(t(unit_vector)%*%solve(sigma)%*%unit_vector)
    weight <- (1/gamma)R%*%mu
    sqr_shrp <- t(mu)%*%R%*%mu
    utility <-  sqr_shrp/(2*gamma)
  }
  result <- list(weight, sqr_shrp, utility)
  return(result)
}

out_of_sample_result <- function(n, t, sigma, mu, gamma, implemented_type){
  table1_result_G <- table1_portfolio_result(sigma, mu, gamma, "G")
  weight_G <- table1_result_G[[1]]
  sqr_shrp_G <- table1_result_G[[2]]
  mu_G <- weight_G %*% mu
  sqr_sigma_G <- t(weight_G)%*%sigma%*%weight_G

  table1_result_H <- table1_portfolio_result(sigma, mu, gamma, "H")
  weight_H <- table1_result_H[[1]]
  sqr_shrp_H <- table1_result_H[[2]]
  
  
  Y1 = ((n+1)/(t-n-1))*draw.noncentral.F(n*t,n+1,t-n-1,t*sqr_shrp_H,1)
  Y2 = ((n-1)/(t-n-1))*draw.noncentral.F(n*t,n-1,t-n-1,t*sqr_shrp_H,1)
  f1 = Y1/(Y1+((n-k)/t))
  f2 = Y2/(Y2+((n-k)/t))
  
  Ef1 = mean(f1)
  Ef2_sqr = mean((f2^2)*Y2)
  Ef2Y2 = mean(f2*Y2)
  
  if (implemented_type == "KZ") {
    k1 = (t - n - 1)*(t-n-4)/(2*gamma*(t-2)*(t-n-2))
    k2 = (t-n-4)*(t-n-5)/(2*gamma*(t-2)*(t-n-2)*(t-n-3))
    k3 = (t-4)*(t-n-1)*(t-n-4)/(2*gamma*t*(t-2)*(t-n-2)*(t-n-3))
    k4 = (t-n-4)/(gamma*(t-2))
    k5 = -(t-n-1)*((t-n-4)^2)/(2*gamma*t*(t-2)*(t-n))
    k6 = -(t-n-1)*((t-n-4)^2)/(gamma*t*(t-2)*(t-n)*(t-n-2))
  }
  if (implemented_type == "QS" | implemented_type == "QSa") {
    k1 = (t - n - 1)*(t-n-4)/(2*gamma*(t-2)*(t-n-2))
    k2 = (t-n-4)*(t-n-5)/(2*gamma*(t-2)*(t-n-2)*(t-n-3))
    k3 = -(t-4)*(t-n-1)*(t-n-4)/(2*gamma*t*(t-2)*(t-n-2)*(t-n-3))
    k4 = (t-n)*(t-n-5)*(t-n-7)/(gamma*t*(t-2)*(t-n-1))
    k5 = -(t-n)*((t-n-5)^2)*((t-n-7)^2)/(2*gamma*(t^3)*(t-2)*(t-n-1))
    k6 = -(t-n-4)*(t-n-5)/(gamma*(t^2)*(t-2)*(t-n-2))
  }
  VG = k1 * sqr_shrp_G + k2 * sqr_shrp_H + k3
  VH = k4 * Ef1 + k5 * Ef2_sqr
  VGH = k6 * Ef2Y2
}

