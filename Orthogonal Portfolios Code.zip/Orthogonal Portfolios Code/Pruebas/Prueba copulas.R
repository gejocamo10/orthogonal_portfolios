# Thesis Code: Dejo and Campos -------------------------------------------------
# Libraries and functions ------------------------------------------------------
rm(list = ls())
library(tidyverse)
library(stargazer)
library(copula)
# setwd("C:/Users/gj.camposm/OneDrive - Universidad del Pac?fico/UP/Ciclo 11/1. IE 2/Trabajo Investigacion Economica/Codigo")
setwd("C:/Users/geral/OneDrive - Universidad del Pacífico/UP/Ciclo 11/1. IE 2/Trabajo Investigacion Economica/Codigo")
source("Resultados.R")

# Copulas ----------------------------------------------------------------------

df_gabo_copulas <- df_gabo %>% select(-date)
df_gabo_copulas_pseudo <- pobs(df_gabo_copulas)
ncol_gabo <- ncol(df_gabo_copulas_pseudo)
fitcopula_gabo <- fitCopula(tCopula(dim=ncol_gabo,dispstr='un'), df_gabo_copulas_pseudo,
                            method = 'ml')
summary(fitcopula_gabo)

# Simulations
list_sim <- rep(1000,100)
list_sim <- lapply(list_sim, rCopula, fitcopula_gabo@copula) %>%
  lapply(as.data.frame)
list_result <- lapply(list_sim, performance_table, 'implementable', 500, gamma = 1)

KZ = c()
Q = c()
M = c()
QS = c()
QSa = c()

for (i in 1:100) {
   KZ[i] =  list_result[[i]][1,1]
   Q[i] = list_result[[i]][1,2]
   M[i] = list_result[[i]][1,3]
   QS[i] = list_result[[i]][1,4]
   QSa[i] = list_result[[i]][1,5]
}
df_simulation <- cbind(KZ,Q,M,QS,QSa) %>% as.data.frame()
df_simulation %>% colMeans()
t.test(KZ, QS, data = df_simulation)

# Bootrstapping ----------------------------------------------------------------


# df_gabo_bootstraping <- df_gabo %>% select(-date) 
# vector_index <- sample(102, 100, replace = T) %>% as.vector()
# n <-  (nrow(df_gabo_bootstraping) - 30)
# KZ = c()
# Q = c()
# M = c()
# QS = c()
# QSa = c()
# for (i in vector_index) {
#   if (i > n) { next }
#   else{
#     n_index = vector_index[i]
#     df_gabo_resampling <- df_gabo_bootstraping[n_index:(n_index+30),]
#     df_result <- performance_table(df_gabo_resampling,'implementable',30,gamma = 1)
#     append(KZ, df_result[1,1], after = length(KZ))
#     append(Q, df_result[1,2], after = length(Q))
#     append(M, df_result[1,3], after = length(M))
#     append(QS, df_result[1,4], after = length(QS))
#     append(QSa, df_result[1,5], after = length(QSa))
#     
#   }
# 
# }


# KZ = c()
# Q = c()
# M = c()
# QS = c()
# QSa = c()
# for (i in 1:100) {
#   df_gabo_resampling <-  slice_sample(df_gabo_bootstraping, n = 60,replace = TRUE)
#   print(performance_table(df_gabo_resampling,'implementable',30,gamma = 1))
#   KZ[i] =  df_result[1,1]
#   Q[i] = df_result[1,2]
#   M[i] = df_result[1,3]
#   QS[i] = df_result[1,4]
#   QSa[i] = df_result[1,5]
# }
# df_bootrstapping <- cbind(KZ,Q,M,QS,QSa) %>% as.data.frame()
# df_bootrstapping %>% colMeans()
# t.test(KZ, QS, data = df_bootrstapping)

# Sensitivity ------------------------------------------------------------------
list_sim <- seq(1, 100, 1)
df_gabo_sensitivity <- df_gabo %>% select(-date) 
list_result <- lapply(list_sim, performance_table, df = df_gabo_sensitivity, 
                      type_table = 'implementable', n_obs = 100)

KZ = c()
Q = c()
M = c()
QS = c()
QSa = c()

for (i in 1:100) {
  KZ[i] =  list_result[[i]][1,1]
  Q[i] = list_result[[i]][1,2]
  M[i] = list_result[[i]][1,3]
  QS[i] = list_result[[i]][1,4]
  QSa[i] = list_result[[i]][1,5]
}
df_sensitivity <- cbind(KZ,Q,M,QS,QSa) %>% as.data.frame()


