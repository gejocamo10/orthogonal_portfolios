# Thesis Code: Dejo and Campos -------------------------------------------------
# Libraries and functions ------------------------------------------------------
# rm(list = ls())
library(tidyverse)
library(stargazer)
# setwd("C:/Users/gj.camposm/OneDrive - Universidad del Pac?fico/UP/Ciclo 11/1. IE 2/Trabajo Investigacion Economica/Codigo")
setwd("C:/Users/geral/OneDrive - Universidad del Pacífico/UP/Ciclo 11/1. IE 2/Trabajo Investigacion Economica/Codigo")
source("Funciones.R")

# Implementable portfolios -----------------------------------------------------
## Gabo data -------------------------------------------------------------------
df_gabo <- tail(read.csv("factor portfolios excess mensual.csv"), 100)
row.names(df_gabo) <- NULL # reset index
df_gabo_dates <- df_gabo[,1]
df_gabo_returns <- df_gabo[,2:7]
n_gabo <- length(df_gabo_returns)
t_gabo <- length(df_gabo_dates)
sigma_gabo <- cov(df_gabo_returns)
mu_gabo <- df_gabo_returns %>% colMeans() %>% as.vector()
gamma_gabo <- 1
results_gabo_implementable_KZ <- out_of_sample_performance_implementable(n_gabo, t_gabo, sigma_gabo, mu_gabo, gamma_gabo, "KZ")*100
results_gabo_implementable_Q <- out_of_sample_performance_implementable(n_gabo, t_gabo, sigma_gabo, mu_gabo, gamma_gabo, "Q")*100
results_gabo_implementable_M <- out_of_sample_performance_implementable(n_gabo, t_gabo, sigma_gabo, mu_gabo, gamma_gabo, "M")*100
results_gabo_implementable_QS <- out_of_sample_performance_implementable(n_gabo, t_gabo, sigma_gabo, mu_gabo, gamma_gabo, "QS")*100
results_gabo_implementable_QSa <- out_of_sample_performance_implementable(n_gabo, t_gabo, sigma_gabo, mu_gabo, gamma_gabo, "QSa")*100 


## Kenneth data -------------------------------------------------------------------
df_kenneth <- tail(read.csv("kenneth em factor excess mensual.csv"), 100) %>% na.omit()
row.names(df_kenneth) <- NULL  # reset index
df_kenneth_dates <- df_kenneth[,1]
df_kenneth_returns <- df_kenneth[,2:7]
n_kenneth <- length(df_kenneth_returns)
t_kenneth <- length(df_kenneth_dates)
sigma_kenneth <- cov(df_kenneth_returns)
mu_kenneth <- df_kenneth_returns %>% colMeans() %>% as.vector()
gamma_kenneth <- 1
results_Kenneth_implementable_KZ <- out_of_sample_performance_implementable(n_kenneth, t_kenneth, sigma_kenneth, mu_kenneth, gamma_kenneth, "KZ")*100
results_Kenneth_implementable_Q <- out_of_sample_performance_implementable(n_kenneth, t_kenneth, sigma_kenneth, mu_kenneth, gamma_kenneth, "Q")*100
results_Kenneth_implementable_M <- out_of_sample_performance_implementable(n_kenneth, t_kenneth, sigma_kenneth, mu_kenneth, gamma_kenneth, "M")*100
results_Kenneth_implementable_QS <- out_of_sample_performance_implementable(n_kenneth, t_kenneth, sigma_kenneth, mu_kenneth, gamma_kenneth, "QS")*100
results_Kenneth_implementable_QSa <- out_of_sample_performance_implementable(n_kenneth, t_kenneth, sigma_kenneth, mu_kenneth, gamma_kenneth, "QSa")*100

## joint results ---------------------------------------------------------------
results_implementable_gabo <- cbind(results_gabo_implementable_KZ, 
                      results_gabo_implementable_Q, 
                      results_gabo_implementable_M, 
                      results_gabo_implementable_QS,
                      results_gabo_implementable_QSa)
colnames(results_implementable_gabo) <- c("KZ","Q","M","QS","QSa")

results_implementable_Kenneth <- cbind(results_Kenneth_implementable_KZ, 
                        results_Kenneth_implementable_Q,
                        results_Kenneth_implementable_M,
                        results_Kenneth_implementable_QS,
                        results_Kenneth_implementable_QSa)
colnames(results_implementable_Kenneth) <- c("KZ","Q","M","QS","QSa")

results_implementable_gabo
results_implementable_Kenneth
stargazer(results_implementable_gabo,type = "text",summary = F)
stargazer(results_implementable_Kenneth,type = "text",summary = F)

# Theoretical Portfolios -------------------------------------------------------
## Gabo data -------------------------------------------------------------------
results_gabo_theoretical_KZ <- out_of_sample_performance_theoretical(n_gabo, t_gabo, sigma_gabo, mu_gabo, gamma_gabo, "KZ")*100
results_gabo_theoretical_Y <- out_of_sample_performance_theoretical(n_gabo, t_gabo, sigma_gabo, mu_gabo, gamma_gabo, "Y")*100
results_gabo_theoretical_Q <- out_of_sample_performance_theoretical(n_gabo, t_gabo, sigma_gabo, mu_gabo, gamma_gabo, "Q")*100
results_gabo_theoretical_M <- out_of_sample_performance_theoretical(n_gabo, t_gabo, sigma_gabo, mu_gabo, gamma_gabo, "M")*100



## Kenneth data ----------------------------------------------------------------
results_Kenneth_theoretical_KZ <- out_of_sample_performance_theoretical(n_kenneth, t_kenneth, sigma_kenneth, mu_kenneth, gamma_kenneth, "KZ")*100
results_Kenneth_theoretical_Y <- out_of_sample_performance_theoretical(n_kenneth, t_kenneth, sigma_kenneth, mu_kenneth, gamma_kenneth, "Y")*100
results_Kenneth_theoretical_Q <- out_of_sample_performance_theoretical(n_kenneth, t_kenneth, sigma_kenneth, mu_kenneth, gamma_kenneth, "Q")*100
results_Kenneth_theoretical_M <- out_of_sample_performance_theoretical(n_kenneth, t_kenneth, sigma_kenneth, mu_kenneth, gamma_kenneth, "M")*100

## joint results ---------------------------------------------------------------
results_theoretical_gabo <- cbind(results_gabo_theoretical_KZ,
                                  results_gabo_theoretical_Y,
                                    results_gabo_theoretical_Q, 
                                    results_gabo_theoretical_M)
colnames(results_theoretical_gabo) <- c("KZ","Y","Q","M")
rownames(results_theoretical_gabo) <- c("Total")

results_theoretical_Kenneth <- cbind(results_Kenneth_theoretical_KZ, 
                                     results_Kenneth_theoretical_Y,  
                                     results_Kenneth_theoretical_Q,
                                       results_Kenneth_theoretical_M)
colnames(results_theoretical_Kenneth) <- c("KZ","Y","Q","M")
rownames(results_theoretical_Kenneth) <- c("Total")

results_theoretical_gabo
results_theoretical_Kenneth
stargazer(results_theoretical_gabo,type = "text",summary = F)
stargazer(results_theoretical_Kenneth,type = "text",summary = F)

## Compare ---------------------------------------------------------------------

stargazer(results_implementable_gabo,type = "text",summary = F)
stargazer(results_implementable_Kenneth,type = "text",summary = F)
stargazer(results_theoretical_gabo,type = "text",summary = F)
stargazer(results_theoretical_Kenneth,type = "text",summary = F)

cat("Gabo: Estimation risk for KZ", results_theoretical_gabo[1,"KZ"] - results_implementable_gabo[1,"KZ"])
cat("Gabo: Estimation risk for Q", results_theoretical_gabo[1,"Q"] - results_implementable_gabo[1,"QS"])

cat("Kenneth: Estimation risk for KZ", results_theoretical_Kenneth[1,"KZ"] - results_implementable_Kenneth[1,"KZ"])
cat("Kenneth: Estimation risk for Q", results_theoretical_Kenneth[1,"Q"] - results_implementable_Kenneth[1,"QS"]) 
